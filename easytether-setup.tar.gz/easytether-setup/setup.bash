#!/bin/bash
sudo apt install ./libssl1.1_1.1.1f-1ubuntu2.17_amd64.deb
sudo apt install ./easytether_0.8.9_amd64.deb
sudo apt update
