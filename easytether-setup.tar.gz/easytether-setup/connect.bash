#!/bin/bash
sudo easytether-usb
sudo systemctl restart systemd-networkd

